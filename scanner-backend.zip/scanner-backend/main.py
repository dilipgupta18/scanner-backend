
from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import os
from formula_parser import apply_formula

app = FastAPI()

class ScanRequest(BaseModel):
    formula: str
    date: str = None

def load_eod_data(date: str = None):
    folder = "data/eod"
    if date:
        filename = f"cm{pd.to_datetime(date).strftime('%d%b%Y').upper()}bhav.csv"
        path = os.path.join(folder, filename)
    else:
        files = sorted([f for f in os.listdir(folder) if f.endswith(".csv")], reverse=True)
        path = os.path.join(folder, files[0]) if files else None

    if not path or not os.path.exists(path):
        raise FileNotFoundError("EOD CSV not found")

    df = pd.read_csv(path)
    df = df.rename(columns=str.lower)
    df = df.rename(columns={
        "symbol": "symbol",
        "close price": "close",
        "open price": "open",
        "high price": "high",
        "low price": "low",
        "last traded qty": "volume"
    })
    df = df[["symbol", "close", "open", "high", "low", "volume"]]
    return df

@app.post("/scan")
async def scan_stocks(req: ScanRequest):
    try:
        df = load_eod_data(req.date)
        result = apply_formula(df.copy(), req.formula)
        return result.to_dict(orient="records")
    except Exception as e:
        return {"error": str(e)}
