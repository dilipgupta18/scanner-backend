
import requests
import zipfile
import io
import os
from datetime import datetime

def download_bhavcopy(date=None):
    date = datetime.today() if date is None else datetime.strptime(date, "%Y-%m-%d")
    day = date.strftime("%d")
    month = date.strftime("%b").upper()
    year = date.strftime("%Y")

    filename = f"cm{day}{month}{year}bhav.csv"
    zip_filename = f"cm{day}{month}{year}bhav.csv.zip"
    url = f"https://www1.nseindia.com/content/historical/EQUITIES/{year}/{month}/{zip_filename}"

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": "https://www.nseindia.com/"
    }

    print(f"Downloading: {url}")
    r = requests.get(url, headers=headers)
    if r.status_code != 200:
        raise Exception(f"Failed to download file: {r.status_code}")

    with zipfile.ZipFile(io.BytesIO(r.content)) as z:
        z.extract(filename, path="data/eod")
        print(f"Saved: data/eod/{filename}")

if __name__ == "__main__":
    download_bhavcopy()
