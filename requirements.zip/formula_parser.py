
import pandas as pd
import ta
import re

INDICATORS = {
    "RSI": lambda df, period: ta.momentum.RSIIndicator(df["close"], window=int(period)).rsi(),
    "SMA": lambda df, period: ta.trend.sma_indicator(df["close"], window=int(period)),
    "EMA": lambda df, period: ta.trend.ema_indicator(df["close"], window=int(period)),
    "MACD": lambda df, _: ta.trend.macd_diff(df["close"]),
    "BBUpper": lambda df, period: ta.volatility.BollingerBands(df["close"], window=int(period)).bollinger_hband(),
    "BBLower": lambda df, period: ta.volatility.BollingerBands(df["close"], window=int(period)).bollinger_lband(),
    "Supertrend": lambda df, args: ta.trend.STCIndicator(
        close=df["close"],
        fillna=False,
        window_slow=int(args.split(",")[0]),
        window_fast=int(args.split(",")[1])
    ).stc()
}

def apply_formula(df: pd.DataFrame, formula: str) -> pd.DataFrame:
    for indicator in INDICATORS.keys():
        pattern = rf"{indicator}\(([^\)]+)\)"
        matches = re.findall(pattern, formula, re.IGNORECASE)
        for match in matches:
            key = f"{indicator}_{match.replace(',', '_')}"
            if key not in df.columns:
                df[key] = INDICATORS[indicator](df, match)
            formula = formula.replace(f"{indicator}({match})", f"df['{key}']")

    formula = formula.replace("Close", "df['close']")
    formula = formula.replace("Open", "df['open']")
    formula = formula.replace("High", "df['high']")
    formula = formula.replace("Low", "df['low']")
    formula = formula.replace("Volume", "df['volume']")
    formula = formula.replace("AND", "&")
    formula = formula.replace("OR", "|")

    try:
        return df[eval(formula)]
    except Exception as e:
        raise ValueError(f"Error evaluating formula: {e}")
